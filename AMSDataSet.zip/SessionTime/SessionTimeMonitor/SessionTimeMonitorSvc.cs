﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Xml.Linq;
using System.Configuration;
using System.IO;
using System.Management;
using SessionTime.SessionTimeCommon;
using System.Timers;
using SessionTimeCommon;

namespace SessionTime.SessionTimeMonitor
{
    public partial class SessionTimeMonitor : ServiceBase
    {
        Timer timer = new Timer();
        private string dataFilePath = ConfigurationManager.AppSettings["DataFilePath"];
        private string logFilePath = ConfigurationManager.AppSettings["LogFilePath"];
        private string ServerUrl = ConfigurationManager.AppSettings["ServerUrl"];
        private string ApiClass = ConfigurationManager.AppSettings["ApiClass"];
        private double SyscTime = double.Parse( ConfigurationManager.AppSettings["SyscTime"]);


        private Guid currentServiceRunGuid = Guid.NewGuid();

        public SessionTimeMonitor()
        {
            try
            {
                InitializeComponent();
                SessionManager.Initialize(dataFilePath, logFilePath);
                SessionSyncData.Initialize(ServerUrl, ApiClass, dataFilePath,logFilePath);

                CanPauseAndContinue = false;
                CanHandleSessionChangeEvent = true;
                ServiceName = "SessionTimeMonitor";
            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, ex.ToString());
            }
        }

        #region Event handlers

        protected override void OnSessionChange(SessionChangeDescription changeDescription)
        {
            try
            {
                if (changeDescription.Reason == SessionChangeReason.SessionLogon
                    || changeDescription.Reason == SessionChangeReason.SessionLogoff
                    || changeDescription.Reason == SessionChangeReason.SessionLock
                    || changeDescription.Reason == SessionChangeReason.SessionUnlock
                    )
                {
                    SessionManager.LogSessionData(
                        currentServiceRunGuid, 
                        changeDescription.SessionId, 
                        SessionTrackingEvents.OnSessionChange,
                        changeDescription.Reason.ToString());
                }
            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, ex.ToString());
            }
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
                //This statement is used to set interval to 1 minute (= 60,000 milliseconds)
                timer.Interval = SyscTime * 60000.00;
                //enabling the timer
                timer.Enabled = true;

                Utility.Log(logFilePath, "start " + DateTime.Now);
                SessionManager.LogSessionData(
                    currentServiceRunGuid, 
                    -1, 
                    SessionTrackingEvents.OnStart, 
                    String.Empty, 
                    true);

            }
            catch (Exception ex)
            {
                Utility.Log(logFilePath, ex.ToString());
            }
        }

        protected override void OnStop()
        {
            timer.Enabled = false;
        }

        private void OnElapsedTime(object source, ElapsedEventArgs e)
        {
            Utility.Log(logFilePath, "Another entry before " + DateTime.Now);

            SessionSyncData.SyncEmployee();
            Utility.Log(logFilePath, "Another entry after " + DateTime.Now);
        }

        #endregion
    }
}