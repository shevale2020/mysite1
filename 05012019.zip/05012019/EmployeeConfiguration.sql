Create Procedure EmployeeConfiguration
@StaffUserName varchar(100)
As 
Begin
Declare @EmployeeLunchTime Varchar(50)

 Select Top(1)@EmployeeLunchTime=  CONVERT(varchar(25), l.LunchTimeFrom) +'-'+CONVERT(varchar(25),l.LunchTimeTo ) from  Staff s
				 inner join [LunchTimeMaster] L on l.LocationMasterID= s.OFCLoc and l.ShiftID=s.OFCTime
				 where s.StaffUserName= 'sf'

Declare @SyncTime Varchar(50)  = (select Top 1 SyncTime from Staff where StaffUserName= @StaffUserName)

Declare @IdelTime Varchar(50)  = (select Top 1 EIdealTime from Staff where StaffUserName= @StaffUserName)


Declare @output varchar(200)= @EmployeeLunchTime +'~'+@SyncTime+'~'+@IdelTime

select isnull(@output,'')

End
