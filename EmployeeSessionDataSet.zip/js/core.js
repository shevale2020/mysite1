﻿
var _constructEdit = function (data) {
                $.each(data, function (key, value) {
                    var _element = key;
                    this.name = key;
                    this.value = value;

                    var _htmlElement = document.getElementById(_element);
                    var _htmlElementByName = document.getElementsByName(_element);

                    if (_htmlElementByName != null) {
                        if (($(_htmlElementByName).attr('type') == "radio")) {
                            RadionButtonSelectedValueSet(_element, value);
                        }
                        else {
                            if (key.indexOf('$id') == -1) {
                                if (_htmlElement != null || $('.' + _element) != null) {

                                    if ($('#' + _element).is('select[multiple]')) {
                                        var values = value.split(',');
                                        $('#' + _element).val(values);
                                    }
                                    else if ($('#' + _element).attr('type') == 'checkbox') {
                                        if (value == true) {
                                            $('#' + _element).parent().addClass('checked')
                                            _htmlElement.checked = true;
                                        }
                                        else {
                                            $('#' + _element).parent().removeClass('checked')
                                        }
                                    }
                                    else if ($('#' + _element).is('select[multiple]')) {
                                        var values = value.split(',');
                                        $('#' + _element).val(values);
                                    }
                                    else if ($('#' + _element).is('select')) {
                                        $('#' + _element).val( String(value)).trigger("change");
                                    }
                                    else if ($('#' + _element).is('file')) {
                                        $('#' + _element).val(String(value));
                                    }
                                    else {
                                        if (value != null) {
                                            $('#' + _element).each(function () {
                                                if (!$('.' + _element).is('label')) {
                                                    if (
                                                        this.name.indexOf('Date') >= 0 ||
                                                        this.name.indexOf('date') >= 0 ||
                                                        this.name.indexOf('ChequeDate') >= 0 ||
                                                        this.name.indexOf('DOB') >= 0) {
                                                        this.value = value.replace('T00:00:00', '');
                                                        if (value.indexOf('T') >= 0) {
                                                            value = value.substring(0, value.indexOf('T'));
                                                            this.value = value
                                                        }
                                                    } else {
                                                        this.value = value;
                                                    }
                                                }
                                            });
                                            $('.' + _element).each(function () {
                                                this.value = value;
                                            });
                                            $('.' + _element).each(function () {
                                                if ($('.' + _element).is('label')) {
                                                    if (
                                                        $('.' + _element).attr('for').toLowerCase().search('Date') >= 0 ||

                                                        $('.' + _element).attr('for').toLowerCase().search('DOB') >= 0
                                                        ) {
                                                        this.value = value.replace('T00:00:00', '');
                                                        if (value.indexOf('T') >= 0) {
                                                            value = value.substring(0, value.indexOf('T'));
                                                            $('.' + _element).html(value);
                                                        }
                                                    } else {
                                                        $('.' + _element).html(value);

                                                    }
                                                }
                                                else {
                                                    if (
                                                       this.name.indexOf('Date') >= 0 ||
                                                    this.name.indexOf('date') >= 0 ||
                                                        this.name.indexOf('ChequeDate') >= 0 ||
                                                    this.name.indexOf('DOB') >= 0) {
                                                        this.value = value.replace('T00:00:00', '');
                                                        if (value.indexOf('T') >= 0) {
                                                            value = value.substring(0, value.indexOf('T'));
                                                            this.value = value;
                                                        }
                                                    } else {
                                                        this.value = value;
                                                    }

                                                }
                                            });
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
             
};


var _constructArchive = function (data) {
   
        var _elem = $(this);
        if (confirm('Are you sure to delete this record?')) {
            blockForm('Deleting record');
            var _row = _elem.parent().parent();
            var _tid = $(_row).data('rowid');
            var _deleteFunctionParent = _elem.parent().parent().parent().parent();
            var _deleteFunctionName = $(_deleteFunctionParent).data('deletefunction');
            var _url = document.location.href + '/Recycle/' + _tid
            if (_deleteFunctionName != "") {
                _url = document.location.href + '/' + _deleteFunctionName + '/' + _tid;
            }
            else if (_url.indexOf('index') === -1) {
                _url = _url;
            }
            else {
                _url = _url.replace(_url.substr(_url.indexOf('index')), '/Recycle/') + _tid;
            }
            $.ajax({
                "type": "POST",
                "url": _url,
                "dataType": "html",
                "success": function (data) {
                    unBlockForm();
                    data = JSON.parse(data);
                    $('#genMsg').addClass(data.flagClass).html(data.Message).fadeIn();
                    SetupDatatable();
                }
            });
        }
   
};