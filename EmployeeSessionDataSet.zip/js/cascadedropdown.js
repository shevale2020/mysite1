﻿
//    @param url = URL to fetch data(i.e.controller action method
//    returning IEnumerable < SelectListItem > or SelectList)
//    @param source = source dropdownlist name
//    @param target = target dropdownlist name
//    

function cascadeDropDownList(url, source, target) {
    $.ajax({
        type: 'GET',
        url: url,
        data: { Id: $(source).val() },
        dataType: 'json',
        traditional: true,
        success: function (data) {
            // remove previous option contents first
            $('#' + target + ' option').each(function () {
                $(this).remove();
            });

            // add new option contents
            var options = '<option value="0"> All </option>';
            for (var i = 0; i < data.length; i++) {
                options += '<option value=' + data[i].Value + '>' + data[i].Text + '</option>';
            }
            $('#' + target).html(options);
        }
    });
}